## What’s new in this Helm Operator Version
New Release

## Fixes
* NONE

## Prerequisites
RedHat OpenShift version >= 3.11

## Documentation
TBD

## Version History
| Operator | Date                | RedHat Openshift Version    |       Details               |
| -------- | --------------------| --------------------------- | ----------------------------|
| 1.0.16    |   May, 2020         | >=3.11                      |   Update to service iFix  8.0.|
| 1.0.15    |   Apr, 2020         | >=3.11                      |   Update to service iFix  8.0.|
| 1.0.14    |   Mar, 2020         | >=3.11                      |   Update to service iFix  8.0.|
| 1.0.13    |   Mar, 2020         | >=3.11                      |   Update to service iFix  8.0.|
| 1.0.12    |   Feb, 2020         | >=3.11                      |   Update to service iFix  8.0.2020020501 |
| 1.0.11    |   Jan, 2020         | >=3.11                      |   Update to service iFix  8.0.2019123101 |
| 1.0.10    |   Nov, 2019         | >=3.11                      |   Update to service iFix  8.0.2019121100 |
| 1.0.9    |   Nov, 2019         | >=3.11                      |   Update to service iFix 8.0.2019112601 |
| 1.0.8    |   Nov, 2019         | >=3.11                      |   Update to service iFix 8.0.2019111508 |
| 1.0.7    |   Nov, 2019         | >=3.11                      |   Update to service iFix 8.0.2019102506 |
| 1.0.5    |   Oct, 2019         | >=3.11                      |   Update to service iFix 8.0.2019092701 |
| 1.0.4    |   Oct, 2019         | >=3.11                      |   MF image changes |          |
| 1.0.3    |   Sept, 2019        | >=3.11                      |   New env variables in server deployment |
| 1.0.1    |   Sept, 2019        | >=3.11                       |   New Release               |

